package com.hengaiw;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.PropertySource;
@SpringBootApplication(scanBasePackages = "com.hengaiw")
@PropertySource({    
    "file:./config/db.properties",//数据库配置
    "file:./config/pay.properties",//支付配置
}) 
@MapperScan(value = "com.hengaiw.pay.model.dao.mapper")
public class PayService {
	public static void main(String[] args) {
		new SpringApplicationBuilder(PayService.class).web(true).run(args);
	}
}
