package com.hengaiw.controller.base;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.StringUtil;
import com.hengaiw.pay.model.dao.model.HaMerchant;
import com.hengaiw.pay.model.dao.model.HaMerchantProduct;
import com.hengaiw.pay.service.HaMerchantProductService;
import com.hengaiw.pay.service.HaMerchantService;
import com.hengaiw.pay.service.HaProductService;
import com.hengaiw.pub.constant.HaConstants;
import com.hengaiw.pub.constant.HaReturnCodeEnum;
import com.hengaiw.pub.utils.HaLog;
import com.hengaiw.pub.utils.HaUtil;

public class BaseValidateController {
	private final HaLog _log = HaLog.getLog(BaseValidateController.class);
	@Autowired
	private HaMerchantService haMerchantService;
	@Autowired
	private HaMerchantProductService haMerchantProductService;
	@Autowired
	private HaProductService haProductService;
	
	public Object MerchantValidate(JSONObject paramObj) {
		_log.info("###### 开始接收商户信息查询请求 ######");
		String logPrefix = "【商户信息查询】";
		try {
			String merchant_no=paramObj.getString("merchant_no");
			String trade_type_nickname=paramObj.getString("trade_type_nickname");
			String product_type=paramObj.getString("product_type");
			if (StringUtil.isEmpty(merchant_no) || StringUtil.isEmpty(trade_type_nickname)|| StringUtil.isEmpty(product_type)) {
				return HaUtil.makeRetFail(HaUtil.makeReturnMap(HaConstants.RETURN_VALUE_FAIL,"",HaConstants.RETURN_VALUE_FAIL, HaReturnCodeEnum.HA_ERR_000002));
			}
			HaMerchant merchantInfo=new HaMerchant();
			HaMerchantProduct merchantProduct=new HaMerchantProduct();
			merchantInfo.setMerchant_no(merchant_no);
			List<HaMerchant> list=haMerchantService.selectByExamplePage(0, 1, merchantInfo);
			if(list.size()>0) {
				merchantInfo=list.get(0);
		        if(merchantInfo.getMerchant_status()==true) {
		        		_log.info("{}商户信息查询成功{}", logPrefix,JSON.toJSONString(merchantInfo));
		        		merchantProduct.setMerchant_id(merchantInfo.getMerchant_id());
		        		merchantProduct.setMerchant_no(merchant_no);
		        		merchantProduct.setTrade_type_nickname(trade_type_nickname);
		        		merchantProduct.setProduct_type(product_type);
		        		merchantProduct.setProduct_status(true);
		        		List<HaMerchantProduct> productList=haMerchantProductService.selectByExamplePage(0, 10, merchantProduct);
		        		_log.info("{}商户的产品信息查询成功{}", logPrefix,JSON.toJSONString(productList));
		        		if(productList.size()>0) {
		        			List<HaMerchantProduct> productArray=new ArrayList<HaMerchantProduct>();
		        			for(HaMerchantProduct product:productList) {
		        				if (product.getProduct_type().equals("PAY")) {
		        					int fee=paramObj.getIntValue("fee");
		        					if(fee>0 && fee<=product.getMerchant_order_limit() && (fee+product.getMerchant_day_use()<=product.getMerchant_day_limit())) {
		        						productArray.add(product);
		        					}
		        				}else if(product.getProduct_type().equals("DATA")){
		        					//数据查询类产品
		        					productArray.add(product);
		        				}
		        			}
		        			if(productArray.size()>0) {
		        				Map<String, Object> returnMap =new HashMap<String, Object>();
		        				returnMap.put("merchantInfo",merchantInfo);
		        				returnMap.put("merchantProduct",productArray.get(0));
		        				returnMap.put("product", haProductService.selectByPrimaryKey(productArray.get(0).getProduct_id()));
							return returnMap;
		        			}else {
		        				return HaUtil.makeRetFail(HaUtil.makeReturnMap(HaConstants.RETURN_VALUE_FAIL,"",HaConstants.RETURN_VALUE_FAIL, HaReturnCodeEnum.MCH_ERR_000004));
		        			}
		        		}else {
		        			return HaUtil.makeRetFail(HaUtil.makeReturnMap(HaConstants.RETURN_VALUE_FAIL,"",HaConstants.RETURN_VALUE_FAIL, HaReturnCodeEnum.MCH_ERR_000004));
		        		}
		        		
		        }else {
		        		return HaUtil.makeRetFail(HaUtil.makeReturnMap(HaConstants.RETURN_VALUE_FAIL,"",HaConstants.RETURN_VALUE_FAIL, HaReturnCodeEnum.MCH_ERR_000002));
		        }
			}else {
				_log.info("{}商户信息为空。", logPrefix);
	            return HaUtil.makeRetFail(HaUtil.makeReturnMap(HaConstants.RETURN_VALUE_FAIL,"",HaConstants.RETURN_VALUE_FAIL, HaReturnCodeEnum.HA_ERR_000003));
			}
		}catch (Exception e) {
            _log.error(e, "查询商户信息错误");
            return HaUtil.makeRetFail(HaUtil.makeReturnMap(HaConstants.RETURN_VALUE_FAIL,"",HaConstants.RETURN_VALUE_FAIL, HaReturnCodeEnum.MCH_ERR_000001));
        }
	}
}
